#!/bin/bash

# Nom de l'image Docker et du conteneur
IMAGE_NAME="bigpapoo/sae103-html2pdf"
CONTAINER_NAME="weasyprint-container"
LOCAL_DIR="$(pwd)"  # Répertoire local actuel
CONTAINER_DIR="/data"  # Répertoire dans le conteneur

# Assurer que l'image Docker est téléchargée (pull)
docker pull $IMAGE_NAME

# Contenu du fichier PHP
fichier_php="page.php"
cat <<EOL > $fichier_php
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Classement des Médailles</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <h1>Classement des Médailles</h1>
    <table>
        <thead>
            <tr>
                <th>Classement</th>
                <th>Pays</th>
                <th>Or</th>
                <th>Argent</th>
                <th>Bronze</th>
                <th>Total</th>
                <th>Pourcentage</th>
            </tr>
        </thead>
        <tbody>
        <?php
        // Variables pour le chemin du fichier CSV et du répertoire des drapeaux
        \$CHEMIN_CSV = '$CONTAINER_DIR/medailles.csv';
        \$DOSSIER_DRAP = '$CONTAINER_DIR/drapeaux';

        // Commandes bash
        \$script_bash = '
        # Lecture du fichier CSV et ajout des lignes au tableau
        CLASSEMENT=1
        while IFS="," read -r pays or argent bronze; do
          if [ "\$pays" != "Pays" ]; then
            TOTAL_PAYS=\$((or + argent + bronze))
            POURCENTAGE=\$(echo "scale=2; (\$TOTAL_PAYS / \$TOT_MEDAILLES) * 100" | bc)
            DRAPEAU="\$DOSSIER_DRAP/\$pays.webp"
            echo "<tr><td>\$CLASSEMENT</td><td><img src=\"\$DRAPEAU\" alt=\"\$pays\"> \$pays</td><td>\$or</td><td>\$argent</td><td>\$bronze</td><td>\$TOTAL_PAYS</td><td>\$POURCENTAGE%</td></tr>"
            CLASSEMENT=\$((CLASSEMENT + 1))
          fi
        done < "\$CHEMIN_CSV"
        ';

        // Exécution du script bash et affichage du résultat
        echo shell_exec(\$script_bash);
        ?>
        </tbody>
    </table>
</body>
</html>
EOL

# Contenu du fichier CSS
fichier_css="styles.css"
cat <<EOL > $fichier_css
body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    margin: 20px;
}

h1 {
    color: #333;
}

p {
    color: #666;
}
EOL

# Créer et démarrer le conteneur Docker en montant le répertoire local
docker run --name $CONTAINER_NAME -v $LOCAL_DIR:$CONTAINER_DIR -it $IMAGE_NAME /bin/bash -c "
# Chemin du fichier PHP, HTML temporaire, et PDF
fichier_php=\"$CONTAINER_DIR/page.php\"
fichier_html_temp=\"$CONTAINER_DIR/page_temp.html\"
fichier_pdf=\"$CONTAINER_DIR/page.pdf\"

# Exécuter le code PHP et sauvegarder le résultat dans un fichier HTML temporaire
php \$fichier_php > \$fichier_html_temp

# Utiliser WeasyPrint pour convertir le fichier HTML temporaire en PDF
weasyprint \$fichier_html_temp \$fichier_pdf

# Supprimer le fichier HTML temporaire
rm \$fichier_html_temp

echo \"Le fichier PDF a été créé : \$fichier_pdf\"
"

# Nettoyer en supprimant le conteneur Docker
docker rm $CONTAINER_NAME

echo "Tous les fichiers ont été générés et le conteneur Docker a été nettoyé."
