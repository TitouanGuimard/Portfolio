#!/bin/bash

# Nom de l'image Docker et du conteneur
IMAGE_NAME="bigpapoo/sae103-html2pdf"
CONTAINER_NAME="weasyprint-container"
LOCAL_DIR="$(pwd)"  # Répertoire local actuel
CONTAINER_DIR="/data"  # Répertoire dans le conteneur

# Assurer que l'image Docker est téléchargée (pull)
docker pull $IMAGE_NAME

# Créer les fichiers HTML, CSS et PHP dans le répertoire local
fichier_html="page.php"
cat <<EOL > $fichier_html
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Classement des Médailles</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <h1>Classement des Médailles</h1>
    <table>
        <thead>
            <tr>
                <th>Classement</th>
                <th>Pays</th>
                <th>Or</th>
                <th>Argent</th>
                <th>Bronze</th>
                <th>Total</th>
                <th>Pourcentage</th>
            </tr>
        </thead>
        <tbody>
        <?php include('generate_table.php'); ?>
        </tbody>
    </table>
</body>
</html>

EOL

fichier_css="styles.css"
cat <<EOL > $fichier_css
table {
    width: 100%;
    border-collapse: collapse;
    text-align: left;
}
th, td {
    border: 1px solid black;
    padding: 8px;
}
th {
    background-color: #f2f2f2;
}
img {
    width: 30px;
    height: auto;
}

EOL

fichier_php="generate_table.php"
cat <<EOL > $fichier_php
<?php
// Variables pour le chemin du fichier CSV et du répertoire des drapeaux
$CHEMIN_CSV = '$CONTAINER_DIR/tabTrie.csv';
$DOSSIER_DRAP = '$CONTAINER_DIR/listeDrapeaux';

// Vérifiez si le fichier CSV existe
if (!file_exists($CHEMIN_CSV)) {
    echo "Erreur : Le fichier CSV n'existe pas.<br>";
    exit(1);
}

// Lire le fichier CSV et générer les lignes du tableau en PHP
if (($handle = fopen($CHEMIN_CSV, "r")) !== FALSE) {
    $classement = 1;
    $tot_medailles = 0;
    $data = [];

    // Calculer le nombre total de médailles
    while (($row = fgetcsv($handle, 1000, ",")) !== FALSE) {
        if ($row[0] !== "Pays") {
            $tot_medailles += $row[1] + $row[2] + $row[3];
            $data[] = $row;
        }
    }

    // Réouvrir le fichier pour générer le tableau HTML
    rewind($handle);
    while (($row = fgetcsv($handle, 1000, ",")) !== FALSE) {
        if ($row[0] !== "Pays") {
            $total_pays = $row[1] + $row[2] + $row[3];
            $pourcentage = round(($total_pays / $tot_medailles) * 100, 2);
            $drapeau = "$DOSSIER_DRAP/" . $row[0] . ".webp";
            echo "<tr><td>$classement</td><td><img src='$drapeau' alt='" . htmlspecialchars($row[0], ENT_QUOTES, 'UTF-8') . "'> " . htmlspecialchars($row[0], ENT_QUOTES, 'UTF-8') . "</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$total_pays</td><td>$pourcentage%</td></tr>";
            $classement++;
        }
    }
    fclose($handle);
} else {
    echo "Erreur : Impossible d'ouvrir le fichier CSV.<br>";
    exit(1);
}
?>
EOL

# Créer et démarrer le conteneur Docker en montant le répertoire local
docker run --name $CONTAINER_NAME -v $LOCAL_DIR:$CONTAINER_DIR -it $IMAGE_NAME /bin/bash -c "
# Copier les fichiers HTML, CSS et PHP dans le conteneur
cp /data/page.php /data/styles.css /data/generate_table.php .

# Chemin du fichier HTML temporaire et PDF
fichier_html_temp=\"$CONTAINER_DIR/page_temp.html\"
fichier_php=\"$CONTAINER_DIR/page.php\"
fichier_pdf=\"$CONTAINER_DIR/page.pdf\"

# Exécuter le code PHP et sauvegarder le résultat dans un fichier HTML temporaire
php \$fichier_php > \$fichier_html_temp

# Utiliser WeasyPrint pour convertir le fichier HTML temporaire en PDF
weasyprint \$fichier_html_temp \$fichier_pdf

# Supprimer le fichier HTML temporaire
rm \$fichier_html_temp

echo \"Le fichier PDF a été créé : \$fichier_pdf\"
"

# Nettoyer en supprimant le conteneur Docker
docker rm $CONTAINER_NAME

echo "Tous les fichiers ont été générés et le conteneur Docker a été nettoyé."
