<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ma Page PHP</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <h1>Bienvenue sur ma page PHP</h1>
    <p>Ceci est un exemple de page HTML avec du code PHP générée par un script Bash.</p>

    <?php
    // Code PHP inclus
    echo "<p>Date et heure actuelles : " . date("Y-m-d H:i:s") . "</p>";
    ?>
</body>
</html>
