#!/bin/bash

set -x  # Activer le mode de débogage

# URL du site web contenant les informations sur les médailles
url="https://olympics.com/fr/paris-2024/medailles"

echo "Récupération du contenu de la page web..."

# Récupérer le contenu de la page web
content=$(curl -s "$url")
if [ $? -ne 0 ]; then
    echo "Erreur: Échec de la récupération du contenu de la page web."
    exit 1
fi

echo "Extraction du nombre de médailles..."

# Extraire la section du contenu HTML concernant la France
france_section=$(echo "$content" | grep -oP '<div class="emotion-srm-fvu3gb elhe7kv0">.*?<span class="elhe7kv4 emotion-srm-5xu01z">FRA</span>.*?</div>')

if [ -z "$france_section" ]; then
    echo "Erreur: Section France non trouvée."
    exit 1
fi

# Extraire le nombre de médailles d'argent de la France
medailles_argent=$(echo "$france_section" | grep -oP '<span class="e1oix8v91 emotion-srm-19huvme">[0-9]+</span>' | head -n 2 | tail -n 1 | grep -oP '[0-9]+')

if [ -z "$medailles_argent" ]; then
    echo "Erreur: Nombre de médailles d'argent non trouvé."
    exit 1
fi

echo "Nombre de médailles d'argent extraites: $medailles_argent"

# Afficher le nombre de médailles
echo "La France a remporté $medailles_argent médailles d'argent aux JO 2024."
