#!/bin/bash

# Chemins des fichiers
CHEMIN_CSV="tabTrie.csv"
DOSSIER_DRAP="Drapeau/"
FIC_HTML="tableau_medailles.html"
FIC_PDF="tableau_medailles.pdf"
IMG_HTML2PDF="bigpapoo/sae103-html2pdf"

docker image pull bigpapoo/sae103-html2pdf
docker image pull bigpapoo/imagick

# Vérification des dépendances
if ! command -v convert &>/dev/null || [ ! -f "$IMG_HTML2PDF" ]; then
  echo "Erreur : Assurez-vous que ImageMagick et html2pdf sont installés."
  exit 1
fi

# Calcul du total des médailles pour le pourcentage
TOT_MEDAILLES=0
while IFS="," read -r pays or argent bronze; do
  if [ "$pays" != "Pays" ]; then
    TOT_MEDAILLES=$((TOT_MEDAILLES + or + argent + bronze))
  fi
done < "$CHEMIN_CSV"

# Génération du fichier HTML
{
  echo "<html>"
  echo "<head><style>"
  echo "table { width: 100%; border-collapse: collapse; text-align: left; }"
  echo "th, td { border: 1px solid black; padding: 8px; }"
  echo "th { background-color: #f2f2f2; }"
  echo "img { width: 30px; height: auto; }"
  echo "</style></head>"
  echo "<body>"
  echo "<h1>Tableau des Médailles</h1>"
  echo "<table>"
  echo "<tr><th>Classement</th><th>Pays</th><th>Or</th><th>Argent</th><th>Bronze</th><th>Total</th><th>% Médailles</th></tr>"

  # Lecture du fichier CSV et ajout des lignes au tableau
  CLASSEMENT=1
  while IFS="," read -r pays or argent bronze; do
    if [ "$pays" != "Pays" ]; then
      TOTAL_PAYS=$((or + argent + bronze))
      POURCENTAGE=$(echo "scale=2; ($TOTAL_PAYS / $TOT_MEDAILLES) * 100" | bc)
      DRAPEAU="$DOSSIER_DRAP/$pays.webp"
      echo "<tr><td>$CLASSEMENT</td><td><img src=\"$DRAPEAU\" alt=\"$pays\"> $pays</td><td>$or</td><td>$argent</td><td>$bronze</td><td>$TOTAL_PAYS</td><td>$POURCENTAGE%</td></tr>"
      CLASSEMENT=$((CLASSEMENT + 1))
    fi
  done < "$CHEMIN_CSV"

  echo "</table>"
  echo "</body></html>"
} > "$FIC_HTML"

docker pull bigpapoo/sae103-html2pdf
docker run --name weasyprint-container -v $(pwd):/data -it bigpapoo/sae103-html2pdf /bin/bash -c "

weasyprint \$FIC_HTML \$FIC_PDF"

# Résultat
if [ -f "$FIC_PDF" ]; then
  echo "PDF généré avec succès : $FIC_PDF"
else
  echo "Erreur lors de la génération du PDF."
fi
