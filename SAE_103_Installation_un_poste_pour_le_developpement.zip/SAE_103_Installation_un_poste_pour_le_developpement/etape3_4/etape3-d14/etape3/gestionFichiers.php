#!/usr/bin/php
<?php

$poidsMax = 150 * 1024; // 150 Ko
$dimensionMini = ["hauteur" => 320, "largeur" => 200];
$dimensionMaxi = ["hauteur" => 960, "largeur" => 600];

$directory = './Etape 1';
$outputFile = 'logs.txt';
$outputDir = './fichiersTries';
// Échapper le chemin pour éviter les problèmes avec les espaces
$escapedOutputDir = escapeshellarg($outputDir);

if (!is_dir($outputDir)) {
    mkdir($outputDir, 0777, true); // Crée le dossier si nécessaire
}

// Vérifier si le dossier d'entrée existe
if (!is_dir($directory)) {
    die("Erreur : Le dossier '$directory' n'existe pas.\n");
}

// Ouvrir le fichier de logs
$fileHandle = fopen($outputFile, 'w');
if (!$fileHandle) {
    die("Erreur : Impossible de créer le fichier '$outputFile'.\n");
}

// Parcourir les fichiers du dossier
foreach (scandir($directory) as $file) {
    $filePath = $directory . DIRECTORY_SEPARATOR . $file;

    // Ignorer les entrées non valides (comme '.' et '..')
    if (!is_file($filePath)) {
        continue;
    }

    // Utiliser pathinfo pour récupérer les informations du fichier
    $fileInfo = pathinfo($filePath);
    $nom = $fileInfo['filename'];
    $format = $fileInfo['extension'];

    // Échapper le chemin pour éviter les problèmes avec les espaces
    $escapedFilePath = escapeshellarg($filePath);


    $info = getimagesize($filePath);


    // Vérifier si le fichier est une image
    if ($info === false) {
        // Gérer les fichiers non-images
        fwrite($fileHandle, "$file : Ce n'est pas une image.\n");

        if (in_array($format, ["txt", "csv"])) {
            fwrite($fileHandle, "$file : Copié dans le dossier trié.\n");
            $command = "cp $escapedFilePath $escapedOutputDir/";
            shell_exec($command);
        }
        if ($format == "data") {
            fwrite($fileHandle, "Analyse du fichier $file.\n");
            $command = "./gestionData.sh $escapedFilePath";
            shell_exec($command);
        }
        continue;
    }

    // Récupérer les informations sur l'image
    $width = $info[0];
    $height = $info[1];
    $type = $info['mime'];
    $size = filesize($filePath);

    fwrite($fileHandle, "Analyse de l'image '$file' :\n");

    // Vérifier les dimensions
    if ($width < $dimensionMini['largeur'] || $height < $dimensionMini['hauteur']) {
        fwrite($fileHandle, "- Dimensions trop petites : $width x $height\n");
        continue;
    } else {
        // Vérifier le format
        if ($type === 'image/webp') {
            fwrite($fileHandle, "$file : Format WebP détecté.\n");

            $outputWebP = escapeshellarg("$outputDir/$nom.webp");
            if ($width > $dimensionMaxi['largeur'] || $height > $dimensionMaxi['hauteur']) {
                fwrite($fileHandle, "- Dimensions trop grandes : $width x $height\n");
                $command = "convert -resize 960x600 $escapedFilePath $outputWebP";
            } else {
                $command = "cp $escapedFilePath $escapedOutputDir/";

            }

        } else {
            $outputWebP = escapeshellarg("$outputDir/$nom.webp");

            if ($width > $dimensionMaxi['largeur'] || $height > $dimensionMaxi['hauteur']) {
                fwrite($fileHandle, "- Dimensions trop grandes : $width x $height\n");
                $command = "convert -resize 960x600 $escapedFilePath $outputWebP";

            } else {
                fwrite($fileHandle, "- Mauvais format : $type\n");

                $command = "convert $escapedFilePath $outputWebP";
            }

            fwrite($fileHandle, "$file : Converti en WebP et déplacé.\n");
        }
        shell_exec($command);
    }

    if ($size > $poidsMax) {
        fwrite($fileHandle, "- Poids trop lourd : " . round($size / 1024, 2) . " Ko\n");
    }


    fwrite($fileHandle, "\n"); // Ligne vide pour séparer les entrées
}

// Fermer le fichier de logs
fclose($fileHandle);

echo "Analyse terminée. Résultats enregistrés dans '$outputFile'.\n";
?>