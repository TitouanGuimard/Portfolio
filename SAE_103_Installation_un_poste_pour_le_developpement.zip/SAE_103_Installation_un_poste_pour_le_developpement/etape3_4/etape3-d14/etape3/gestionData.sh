#!/bin/bash

# Nom du fichier source
input_file=$1

# Vérifier si le fichier source existe
if [ ! -f "$input_file" ]; then
    echo "Erreur : Le fichier '$input_file' est introuvable."
    exit 1
fi

# Dossier pour les fichiers séparés
output_dir="./fichiersTries"

# Initialiser les variables
current_section=""
output_file=""

# Lire le fichier ligne par ligne
while IFS= read -r line; do
    # Si la ligne contient un séparateur SECTION_(nombre)
    if [[ $line =~ SECTION_([1-9][0-9]?) ]]; then
        # Sauvegarder le numéro de section
        section_number="${BASH_REMATCH[1]}"

        # Définir le nom du fichier de sortie pour cette section
        output_file="$output_dir/SECTION_${section_number}.txt"
    fi

    # Si un fichier de sortie est défini, ajouter la ligne au fichier
    if [[ -n $output_file ]]; then
        echo "$line" >>"$output_file"
    fi
done <"$input_file"
