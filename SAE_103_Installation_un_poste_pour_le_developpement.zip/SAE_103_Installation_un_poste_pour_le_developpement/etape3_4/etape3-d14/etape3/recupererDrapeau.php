#!/usr/bin/php
<?php
// Fonction pour supprimer les accents
$isoNonReferencies = ['gb','cz'];
$isoInvalide = ['Géorgie' => 'us-ga'];
function harmoniserTexte($texte) {
    $translit = [
        'à' => 'a', 'â' => 'a', 'ä' => 'a', 'á' => 'a', 'ã' => 'a', 'å' => 'a',
        'ç' => 'c', 'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e', 'í' => 'i', 'ì' => 'i',
        'î' => 'i', 'ï' => 'i', 'ñ' => 'n', 'ó' => 'o', 'ò' => 'o', 'ô' => 'o', 'ö' => 'o',
        'õ' => 'o', 'ø' => 'o', 'ú' => 'u', 'ù' => 'u', 'û' => 'u', 'ü' => 'u', 
        'À' => 'A', 'Â' => 'A', 'Ä' => 'A', 'Á' => 'A', 'Ã' => 'A',
        'Å' => 'A', 'Ç' => 'C', 'É' => 'E', 'È' => 'E', 'Ê' => 'E', 'Ë' => 'E',
        'Í' => 'I', 'Ì' => 'I', 'Î' => 'I', 'Ï' => 'I', 'Ñ' => 'N', 'Ó' => 'O', 'Ò' => 'O',
        'Ô' => 'O', 'Ö' => 'O', 'Õ' => 'O', 'Ø' => 'O','Ú' => 'U', 'Ù' => 'U',
        'Û' => 'U', 'Ü' => 'U', 'Ý' => 'Y'
    ];
    $texte = strtr($texte, $translit);

    // Remplacer "Rép." par "République", supprimer les espaces et les tirets
    $texte = str_replace(['Rép.', ' ', '-'], ['République', '', ''], $texte);
    
    return $texte;
}
shell_exec("wget https://flagcdn.com/fr/codes.json");

// Charger le fichier JSON
$jsonFile = 'codes.json';
$jsonData = json_decode(file_get_contents($jsonFile), true);

if ($jsonData === null) {
    die("Erreur : Impossible de charger le fichier JSON\n");
}

// Charger le fichier CSV
$csvFile = 'Tableau_des_medailles_v2.csv';
if (!file_exists($csvFile)) {
    die("Erreur : Le fichier CSV n'existe pas\n");
}

// Extraire les noms des pays du fichier CSV
$countriesInCsv = [];
if (($handle = fopen($csvFile, 'r')) !== false) {
    // Sauter les premières lignes inutiles
    for ($i = 0; $i < 3; $i++) {
        fgetcsv($handle);
    }

    // Lire les lignes restantes pour extraire les noms de pays
    while (($data = fgetcsv($handle, 1000, ',')) !== false) {
        $country = trim($data[0]); // Le nom du pays est dans la première colonne
        if (!empty($country)) {
            #echo "Pays traité : $country\n";
            $countriesInCsv[] = harmoniserTexte($country); // Normaliser
        }
    }
    fclose($handle);
} else {
    die("Erreur : Impossible de lire le fichier CSV\n");
}

// Comparer les valeurs des clés JSON avec les pays du CSV
foreach ($jsonData as $key => $value) {
    
    $normalizedValue = harmoniserTexte($value); // Normaliser
    if (in_array($normalizedValue, $countriesInCsv) || in_array($key,$isoNonReferencies)) {

        if ($key!=$isoInvalide['Géorgie']) {
            shell_exec("wget https://flagcdn.com/80x60/$key.webp");
            shell_exec("mv $key.webp $value.webp");
            shell_exec("wget https://flagcdn.com/w20/$key.webp");
            shell_exec("mv $key.webp flat$value.webp");
        } 
    }
}


