docker image pull bigpapoo/sae103-excel2csv

docker run -d --name excel bigpapoo/sae103-excel2csv

# Vérifier que le conteneur tourne
docker ps

# Exécuter une commande dans le conteneur
docker exec -it excel mkdir test

docker exec -it excel ls

# Sortir du shell sans arrêter le conteneur

docker ps -a
