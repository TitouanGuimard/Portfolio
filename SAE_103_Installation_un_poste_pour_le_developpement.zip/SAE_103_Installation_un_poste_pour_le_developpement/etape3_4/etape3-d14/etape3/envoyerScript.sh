#Permet d'envoyer ce que l'on veut
docker container cp "$2" "$1:/data"
