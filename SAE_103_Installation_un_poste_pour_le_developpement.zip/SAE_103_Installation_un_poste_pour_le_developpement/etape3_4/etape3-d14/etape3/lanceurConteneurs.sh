#!/bin/bash

imageImagick=bigpapoo/sae103-imagick
imageWget=bigpapoo/sae103-wget
imageE2C=bigpapoo/sae103-excel2csv
imageH2P=bigpapoo/sae103-html2pdf

echo "Importation des images (prend un peu de temps)..."

# importation des images
docker image pull $imageImagick
docker image pull $imageWget
docker image pull $imageE2C
docker image pull $imageH2P

# on se donne les droits pour le lanceur de scripts
chmod +x lanceurScripts.sh

#-------Conteneur 1-------------

nom1=gestionFichiers

#lancer le conteneur
echo "Vous pouvez exécuter le lanceur de scripts"
echo "Démarrage du conteneur $nom1..."
docker container run -ti --name $nom1 $imageImagick

#-------------------------------

#-------Conteneur 2-------------

nom2=transformTableau

#lancer le conteneur
echo "Démarrage du conteneur $nom2..."
docker container run -ti --name $nom2 $imageE2C

#-------------------------------

#-------Conteneur 3-------------

nom3=traitementTableau

#lancer le conteneur
echo "Démarrage du conteneur $nom3..."
docker container run -ti --name $nom3 $imageImagick

#-------------------------------

#-------Conteneur 4-------------

nom4=recupererDrapeau

#lancer le conteneur
echo "Démarrage du conteneur $nom4..."
docker container run -ti --name $nom4 $imageWget

#-------------------------------
