#on se donne les droits d'executer tous les scripts
chmod +x gestionFichiers.php
chmod +x gestionData.sh
chmod +x ScriptTab.php
chmod +x envoyerScript.sh
chmod +x recupererDrapeau.php

#------------ Script 1 ---------------

#ce script s'occupe de transformer les images en webp et de traiter les .data en plusieurs .txt

echo "Début du script n°1"

nom1=gestionFichiers

./envoyerScript.sh "$nom1" "./gestionFichiers.php"
./envoyerScript.sh "$nom1" "./gestionData.sh"
./envoyerScript.sh "$nom1" "./Etape 1"

docker exec $nom1 ./gestionFichiers.php

docker cp $nom1:/data/fichiersTries ./
docker cp $nom1:/data/logs.txt ./

docker rm -f $nom1

echo "Fin du script n°1"

#------------------------------------

echo "Attente que le conteneur se lance bien"
sleep 3

#------------ Script 2 ---------------

#ce script s'occupe de transformer le tableau des médailles en csv

echo "Début du script n°2"

nom2=transformTableau

cp "./Etape 1/Tableau des médailles v2.xlsx" "./Etape 1/Tableau des medailles v2.xlsx"

./envoyerScript.sh "$nom2" "./Etape 1/Tableau des medailles v2.xlsx"

docker exec $nom2 ssconvert "../data/Tableau des medailles v2.xlsx" "../data/Tableau_des_medailles_v2.csv"

docker cp "$nom2:/data/Tableau_des_medailles_v2.csv" "./Etape 1"

rm "./Etape 1/Tableau des medailles v2.xlsx"
docker rm -f $nom2

echo "Fin du script n°2"

#------------------------------------

echo "Attente que le conteneur se lance bien"
sleep 3

#------------ Script 3 ---------------

#ce script s'occupe de trier les pays dans le tableau des médailles et faire la somme de leurs médailles

nom3=traitementTableau

echo "Début du script n°3"

#enlever les problèmes liés à Windows car le script a été fait sur une VM
sed -i 's/\r$//' ScriptTab.php

./envoyerScript.sh $nom3 "./ScriptTab.php"

./envoyerScript.sh "$nom3" "./Etape 1/Tableau_des_medailles_v2.csv"

docker exec $nom3 "./ScriptTab.php"

docker cp $nom3:/data/tabTrie.csv ./fichiersTries

docker rm -f $nom3

echo "Fin du script n°3"

#------------------------------------

echo "Attente que le conteneur se lance bien"
sleep 3

#------------ Script 4 ---------------

#ce script s'occupe de créer un dossier avec les drapeaux de tous les pays des JO

nom4=recupererDrapeau

echo "Début du script n°4"

./envoyerScript.sh $nom4 "./recupererDrapeau.php"

./envoyerScript.sh "$nom4" "./Etape 1/Tableau_des_medailles_v2.csv"

./envoyerScript.sh "$nom4" "./codes.json"

docker exec $nom4 "./recupererDrapeau.php"

docker cp $nom4:/data ./fichiersTries

mv ./fichiersTries/data ./fichiersTries/listeDrapeaux

docker rm -f $nom4

echo "Fin du script n°4"

#------------------------------------

#--------  Nettoyage  ------------

rm "./fichiersTries/listeDrapeaux/recupererDrapeau.php"
rm "./fichiersTries/listeDrapeaux/Tableau_des_medailles_v2.csv"
rm "./fichiersTries/listeDrapeaux/codes.json"

rm "./fichiersTries/listeDrapeaux/*.webp.1"
rm "./fichiersTries/listeDrapeaux/??.webp"

echo "Fin du script, les documents demandés sont dans le dossier 'fichiersTries'"
