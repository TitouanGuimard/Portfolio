#!/usr/bin/php
<?php
$input_file = './Tableau_des_medailles_v2.csv';
$output_file = 'tabTrie.csv';

// Lire le fichier CSV
$data = array_map('str_getcsv', file($input_file));

// Extraire l'en-tête et les données
$header = array_shift($data);

// Calculer le total des médailles et préparer les données
foreach ($data as &$row) {
    $row[1] = (int) $row[1]; // Médailles d'or
    $row[2] = (int) $row[2]; // Médailles d'argent
    $row[3] = (int) $row[3]; // Médailles de bronze
    $row[4] = $row[1] + $row[2] + $row[3]; // Total des médailles
}
unset($row); // Rompre la référence

// Trier les données
usort($data, function ($a, $b) {
    // Trier par médailles d'or (décroissant)
    if ($b[1] !== $a[1])
        return $b[1] - $a[1];
    // Trier par médailles d'argent (décroissant)
    if ($b[2] !== $a[2])
        return $b[2] - $a[2];
    // Trier par médailles de bronze (décroissant)
    if ($b[3] !== $a[3])
        return $b[3] - $a[3];
    // Trier par nom du pays (alphabétique)
    return strcmp($a[0], $b[0]);
});

// Attribuer les rangs et réorganiser les colonnes
$output = [];
$prev = [-1, -1, -1]; // Stocke les médailles du pays précédent
$rank = 0; // Rang actuel
$ex_aequo = 0; // Nombre d'ex-æquo

foreach ($data as $index => $row) {
    if (
        $row[1] === $prev[0] && // Même nombre de médailles d'or
        $row[2] === $prev[1] && // Même nombre de médailles d'argent
        $row[3] === $prev[2]    // Même nombre de médailles de bronze
    ) {
        $classement = "-"; // Ex-aequo : afficher un tiret
        $ex_aequo++;
    } else {
        $rank += 1 + $ex_aequo; // Passer les ex-aequo pour le prochain rang
        $classement = $rank; // Affecter le nouveau rang
        $ex_aequo = 0; // Réinitialiser le compteur d'ex-æquo
    }

    // Réorganiser les colonnes : Classement, Pays, Or, Argent, Bronze, Total
    $output[] = array_merge([$classement], $row);
    $prev = [$row[1], $row[2], $row[3]]; // Mettre à jour les médailles précédentes
}

// Ajouter "Classement" à l'en-tête et écrire dans le fichier de sortie
$fp = fopen($output_file, 'w');
fputcsv($fp, array_merge(['Classement'], $header, ['Total']));
foreach ($output as $row) {
    fputcsv($fp, $row);
}
fclose($fp);

echo "Résultats triés dans $output_file\n";
?>