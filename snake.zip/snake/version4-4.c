/**
 * @file serpent.c
 * @brief Jeu de serpent avec des pavés et des pommes.
 */

#include <stdio.h>
#include <stdlib.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <stdbool.h>

int TAILLE = 10; 

#define ANNEAUX 'X'
#define TETE_SERPENT 'O' 
#define TEMPORISATION 200000 ///< Temporisation en microsecondes
#define TOUCHE_ARRET 'a' ///< Touche d'arrêt
#define INIT_POS_X 40 ///< Position initiale x
#define INIT_POS_Y 20 ///< Position initiale y
#define DIRECTION_HAUT 'z'
#define DIRECTION_BAS 's'
#define DIRECTION_GAUCHE 'q'
#define DIRECTION_DROITE 'd'
#define LARGEUR 80 ///< Largeur de l'écran
#define HAUTEUR 40 ///< Hauteur de l'écran
#define NB_PAVES 4 ///< Nombre de pavés
#define TAILLE_PAVE 5 ///< Taille du pavé
#define POMME '6'

typedef struct {
    int x; ///< Position x du pavé
    int y; ///< Position y du pavé
} Pave;

Pave paves[NB_PAVES];

void afficher(char plateau[HAUTEUR][LARGEUR]) {
    system("clear");
    for (int y = 0; y < HAUTEUR; y++) {
        for (int x = 0; x < LARGEUR; x++) {
            printf("%c", plateau[y][x]);
        }
        printf("\n");
    }
}

void initPlateau(char plateau[HAUTEUR][LARGEUR]) {
    // Initialiser le plateau avec des espaces
    for (int y = 0; y < HAUTEUR; y++) {
        for (int x = 0; x < LARGEUR; x++) {
            plateau[y][x] = ' ';
        }
    }
    // Ajouter la bordure avec des issues
    for (int x = 0; x < LARGEUR; x++) {
        if (x == LARGEUR / 2) {
            plateau[0][x] = ' '; // Issue en haut
            plateau[HAUTEUR-1][x] = ' '; // Issue en bas
        } else {
            plateau[0][x] = '#';
            plateau[HAUTEUR-1][x] = '#';
        }
    }
    for (int y = 0; y < HAUTEUR; y++) {
        if (y == HAUTEUR / 2) {
            plateau[y][0] = ' '; // Issue à gauche
            plateau[y][LARGEUR-1] = ' '; // Issue à droite
        } else {
            plateau[y][0] = '#';
            plateau[y][LARGEUR-1] = '#';
        }
    }
}

void dessinerPave(char plateau[HAUTEUR][LARGEUR], int x, int y) {
    for (int i = 0; i < TAILLE_PAVE; i++) {
        for (int j = 0; j < TAILLE_PAVE; j++) {
            plateau[y + j][x + i] = '#';
        }
    }
}

void placerPaves(char plateau[HAUTEUR][LARGEUR], int lesX[], int lesY[]) {
    srand(time(NULL));
    for (int i = 0; i < NB_PAVES; i++) {
        bool positionValide;
        int x, y;
        do {
            positionValide = true;
            x = (rand() % (LARGEUR - TAILLE_PAVE - 2)) + 1;
            y = (rand() % (HAUTEUR - TAILLE_PAVE - 2)) + 1;
            for (int j = 0; j < TAILLE; j++) {
                if (x >= lesX[j] && x < lesX[j] + TAILLE_PAVE &&
                    y >= lesY[j] && y < lesY[j] + TAILLE_PAVE) {
                    positionValide = false;
                    break;
                }
            }
        } while (!positionValide);
        
        paves[i].x = x;
        paves[i].y = y;
        dessinerPave(plateau, x, y);
    }
}

void dessinerSerpent(char plateau[HAUTEUR][LARGEUR], int lesX[], int lesY[]) {
    plateau[lesY[0]][lesX[0]] = TETE_SERPENT; // Tête
    for (int i = 1; i < TAILLE; i++) {
        plateau[lesY[i]][lesX[i]] = ANNEAUX; // Anneaux
    }
}

int collisionPave(int x, int y) {
    for (int i = 0; i < NB_PAVES; i++) {
        if (x >= paves[i].x && x < paves[i].x + TAILLE_PAVE &&
            y >= paves[i].y && y < paves[i].y + TAILLE_PAVE) {
            return 1;
        }
    }
    return 0;
}

int collisionSerpent(int lesX[], int lesY[]) {
    for (int i = 1; i < TAILLE; i++) {
        if (lesX[0] == lesX[i] && lesY[0] == lesY[i]) {
            return 1;
        }
    }
    return 0;
}

void gotoXY(int x, int y) { 
    printf("\033[%d;%df", y, x);
}

void effacer(int x, int y) {
    gotoXY(x, y);
    printf(" ");
    gotoXY(0,0);
}

void progresser(char plateau[HAUTEUR][LARGEUR], int lesX[], int lesY[], char direction, bool *collision, bool *pommeMangee) {
    plateau[lesY[TAILLE-1]][lesX[TAILLE-1]] = ' ';
    effacer(lesX[TAILLE-1], lesY[TAILLE-1]);

    for (int i = TAILLE-1; i > 0; i--) {
        lesX[i] = lesX[i-1];
        lesY[i] = lesY[i-1];
    }
    switch (direction) {
        case DIRECTION_HAUT: lesY[0]--; break;
        case DIRECTION_BAS: lesY[0]++; break;
        case DIRECTION_GAUCHE: lesX[0]--; break;
        case DIRECTION_DROITE: lesX[0]++; break;
    }

    // Vérifier et gérer les issues
    if (lesX[0] < 0) lesX[0] = LARGEUR - 1;
    if (lesX[0] >= LARGEUR) lesX[0] = 0;
    if (lesY[0] < 0) lesY[0] = HAUTEUR - 1;
    if (lesY[0] >= HAUTEUR) lesY[0] = 0;

    *collision = collisionPave(lesX[0], lesY[0]) || collisionSerpent(lesX, lesY);
    *pommeMangee = (plateau[lesY[0]][lesX[0]] == POMME);
}

int kbhit() {
    int unCaractere = 0;
    struct termios oldt, newt;
    int ch;
    int oldf;

    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

    ch = getchar();

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);

    if(ch != EOF){
        ungetc(ch, stdin);
        unCaractere = 1;
    } 
    return unCaractere;
}

void disableEcho() {
    struct termios tty;
    if (tcgetattr(STDIN_FILENO, &tty) == -1) {
        perror("tcgetattr");
        exit(EXIT_FAILURE);
    }
    tty.c_lflag &= ~ECHO;
    if (tcsetattr(STDIN_FILENO, TCSANOW, &tty) == -1) {
        perror("tcsetattr");
        exit(EXIT_FAILURE);
    }
}

void enableEcho() {
    struct termios tty;
    if (tcgetattr(STDIN_FILENO, &tty) == -1) {
        perror("tcgetattr");
        exit(EXIT_FAILURE);
    }
    tty.c.lflag |= ECHO;
    if (tcsetattr(STDIN_FILENO, TCSANOW, &tty) == -1) {
        perror("tcsetattr");
        exit(EXIT_FAILURE);
    }
}

void ajouterPomme(char plateau[HAUTEUR][LARGEUR], int lesX[], int lesY[]) {
    srand(time(NULL));
    int x, y;
    bool positionValide;

    do {
        positionValide = true;
        x = rand() % LARGEUR;
        y = rand() % HAUTEUR;

        // Vérifier que la position n'est pas occupée par un pavé ou par le serpent
        if (plateau[y][x] == '#') {
            positionValide = false;
        } else {
            for (int i = 0; i < TAILLE; i++) {
                if (lesX[i] == x && lesY[i] == y) {
                    positionValide = false;
                    break;
                }
            }
        }
    } while (!positionValide);

    plateau[y][x] = POMME;
    gotoXY(x, y);
    printf("%c", POMME);
}

int main() {
    char plateau[HAUTEUR][LARGEUR];
    int *lesX = malloc(TAILLE * sizeof(int));
    int *lesY = malloc(TAILLE * sizeof(int));
    char direction = DIRECTION_DROITE;
    bool collision = false;
    bool pommeMangee = false;
    int nombreDePommes = 0;
    int vitesse = TEMPORISATION;

    for (int i = 0; i < TAILLE; i++) {
        lesX[i] = INIT_POS_X - i;
        lesY[i] = INIT_POS_Y;
    }

    initPlateau(plateau);
    placerPaves(plateau, lesX, lesY);
    ajouterPomme(plateau, lesX, lesY);

    disableEcho();

    while (nombreDePommes < 10) {
        if (kbhit()) {
            char new_direction = getchar();
            if (new_direction == TOUCHE_ARRET) {
                break;
            } else if ((new_direction == DIRECTION_HAUT && direction != DIRECTION_BAS) ||
                       (new_direction == DIRECTION_BAS && direction != DIRECTION_HAUT) ||
                       (new_direction == DIRECTION_GAUCHE && direction != DIRECTION_DROITE) ||
                       (new_direction == DIRECTION_DROITE && direction != DIRECTION_GAUCHE)) {
                direction = new_direction;
            }
        }

        dessinerSerpent(plateau, lesX, lesY);
        afficher(plateau);
        usleep(vitesse);
        progresser(plateau, lesX, lesY, direction, &collision, &pommeMangee);

        if (collision) {
            system("clear");
            printf("\nCollision! Game Over.\n");
            break;
        }

        if (pommeMangee) {
            nombreDePommes++;
            if (nombreDePommes == 10) {
                system("clear");
                printf("\nVous avez gagné!\n");
                break;
            }
            TAILLE++;
            lesX = realloc(lesX, TAILLE * sizeof(int));
            lesY = realloc(lesY, TAILLE * sizeof(int));
            ajouterPomme(plateau, lesX, lesY);
            vitesse -= 10000; // Augmentez la vitesse en diminuant la temporisation
        }
    }

    enableEcho();
    free(lesX);
    free(lesY);

    return 0;
}
