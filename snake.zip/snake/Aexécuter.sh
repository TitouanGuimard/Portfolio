chmod +x version4-4

./version4-4